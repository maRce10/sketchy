# Global variables
if(getRversion() >= "3.5.0")  utils::globalVariables(c("compendiums", "manuscript_template", "apa.csl", "readme"))
