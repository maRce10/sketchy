sketchy 1.0.4
=========================

### NEW FEATURES

* New function `spot_unused_files()` to spot/remove unused files in a project directory

* New function `open_wd()` to open the current working directory

sketchy 1.0.3
=========================

### MINOR IMPROVEMENTS

* Remove 'comments' argument in `make_compendium()`

### NEW FEATURES

* New function `check_urls()` to check url addresses

sketchy 1.0.0
=========================

* First release
